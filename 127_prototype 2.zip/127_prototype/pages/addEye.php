<?php
	$connect = mysqli_connect('localhost','root','');
	
	if(!$connect){
		echo 'No connection to server';
	}
	if(!mysqli_select_db($connect,'lukedb')){
		echo 'Database "lukedb" is not selected';
	}
	$patient_id=$_POST['patient_id'];
	$visualacuityl=$_POST['visualacuityl'];
	$visualacuityr=$_POST['visualacuityr'];
	$visualacuity=$visualacuityl." ".$visualacuityr;
	$withpinholel=$_POST['withpinholel'];
	$withpinholer=$_POST['withpinholer'];
	$withpinhole=$withpinholel." ".$withpinholer;
	$rxl=$_POST['rxl'];
	$rxr=$_POST['rxr'];
	$rx=$rxl." ".$rxr;
	$pdl=$_POST['pdl'];
	$pdr=$_POST['pdr'];
	$pd=$pdl." ".$pdr;
	$eyeremark=$_POST['eyeremark']
	$sql="INSERT INTO eye(PATIENT_ID,VISUAL_ACUITY,WITH_PINHOLE,RX,PD,EYE_REMARK) VALUES ('$patient_id','$visualacuity','$withpinhole','$rx','$pd','$eyeremark')";
	if(!mysqli_query($connect,$sql)){
		echo 'Insert failure';
	}else{
		echo 'Inserted';
	}
	header("refresh:0.2; url=eye.php");
?>